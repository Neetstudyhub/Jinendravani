// Define global variable (no export)
var cards = [
  {
    title1: "Gayatri Mantra",
    title2: "The Gayatri Mantra",
    url: "pages/gayatri.html",
    thumbnail: "images/gayatri.jpg"
  },
  {
    title1: "Hanuman Chalisa",
    title2: "The Hanuman Chalisa",
    url: "pages/hanuman.html",
    thumbnail: "images/hanuman.jpg"
  },
  {
    title1: "Shiv Tandav",
    title2: "The Shiv Tandav Stotram",
    url: "pages/shivtandav.html",
    thumbnail: "images/shivtandav.jpg"
  }
  // Add more cards here...
];
