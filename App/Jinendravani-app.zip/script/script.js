    // hamburgur opening closing 



  document.addEventListener("DOMContentLoaded", function () {
    const menu = document.querySelector(".hamburgur-menu");
    const openBtn = document.querySelector(".hamburgur-icon");
    const closeBtn = document.querySelector(".cross-icon");

    // Create overlay dynamically
    const overlay = document.createElement("div");
    overlay.className = "menu-overlay";
    document.body.appendChild(overlay);

    function openMenu() {
      menu.classList.add("active");
      overlay.style.display = "block";
      document.body.classList.add("menu-open");
    }

    function closeMenu() {
      menu.classList.remove("active");
      overlay.style.display = "none";
      document.body.classList.remove("menu-open");
    }

    openBtn.addEventListener("click", (e) => {
      e.stopPropagation();
      openMenu();
    });

    closeBtn.addEventListener("click", (e) => {
      e.stopPropagation();
      closeMenu();
    });

    overlay.addEventListener("click", () => {
      closeMenu();
    });

    document.addEventListener("click", function (event) {
      const isClickInsideMenu = menu.contains(event.target);
      const isClickOnButton = openBtn.contains(event.target);

      if (!isClickInsideMenu && !isClickOnButton) {
        closeMenu();
      }
    });

    menu.addEventListener("click", (e) => {
      e.stopPropagation();
    });
  });



// mobile sub menu
  document.addEventListener("DOMContentLoaded", function () {
    const submenu = document.querySelector(".submenu");
    const submenuContainer = document.querySelector(".submenu-container");
    const chevronIcon = submenu.querySelector(".fas-submenu");

    // Toggle submenu on click
    submenu.addEventListener("click", (e) => {
      e.stopPropagation(); // Prevent click from bubbling to document
      submenuContainer.classList.toggle("active");
      chevronIcon.classList.toggle("rotate-chevron");
    });

    // Close submenu when clicking outside
    document.addEventListener("click", function (event) {
      const isClickInside = submenu.contains(event.target) || submenuContainer.contains(event.target);

      if (!isClickInside && submenuContainer.classList.contains("active")) {
        submenuContainer.classList.remove("active");
        chevronIcon.classList.remove("rotate-chevron");
      }
    });
  });

// audio

  function toggleAudio(button) {
    const audio = document.getElementById("mahaveerAudio");
    const icon = button.querySelector("i");
    const word = button.querySelector(".action-word");

    if (audio.paused) {
      audio.play();
      icon.className = "fa-solid fa-circle-pause hero-fas";
      icon.style.marginRight = "6px"; // Add margin on pause icon
      word.textContent = "रोके";
      button.classList.add("pause");
    } else {
      audio.pause();
      icon.className = "fa-solid fa-headphones hero-fas";
      icon.style.marginRight = ""; // Remove margin
      word.textContent = "सुने";
      button.classList.remove("pause");
    }

    // Reset when audio ends
    audio.onended = () => {
      icon.className = "fa-solid fa-headphones hero-fas";
      icon.style.marginRight = ""; // Remove margin
      word.textContent = "सुने";
      button.classList.remove("pause");
    };
  }
document.addEventListener("DOMContentLoaded", function () {
  const searchInput = document.getElementById("searchInput");
  const clearBtn = document.querySelector(".clear-input");
  const voiceBtn = document.querySelector(".voice-search");
  const searchIcon = document.querySelector(".header-search-icon");
  const searchSection = document.querySelector(".search-section-top");

  // Voice elements
  const voicePopup = document.getElementById("voicePopup");
  const voiceText = document.getElementById("voiceText");
  const voiceClose = document.getElementById("voiceClose");
  const stopBtn = document.getElementById("stopListeningBtn");
  const tryAgainBtn = document.getElementById("tryAgainBtn");

  let recognition;
  let didRecognizeSpeech = false;

  function startVoiceRecognition() {
    if (!('webkitSpeechRecognition' in window)) {
      alert("Voice search not supported in your browser.");
      return;
    }

    recognition = new webkitSpeechRecognition();
    recognition.lang = "en-IN";
    recognition.interimResults = true;
    recognition.continuous = false;

    didRecognizeSpeech = false;
    voiceText.textContent = "Listening...";
    tryAgainBtn.style.display = "none";
    voicePopup.style.display = "flex";

    recognition.start();

    recognition.onresult = function (event) {
      let transcript = "";
      for (let i = event.resultIndex; i < event.results.length; ++i) {
        transcript += event.results[i][0].transcript;
      }
      if (transcript.trim()) didRecognizeSpeech = true;
      voiceText.textContent = transcript;
    };

    recognition.onerror = function (event) {
      recognition.stop();
      showTryAgain("Could not hear anything");
    };

    recognition.onend = function () {
      voicePopup.style.display = "flex";
      if (didRecognizeSpeech && voiceText.textContent.trim()) {
        searchInput.value = voiceText.textContent.trim();
        clearBtn.style.display = "inline-block";
        voicePopup.style.display = "none";
        searchInput.form.submit();
      } else {
        showTryAgain("No speech detected");
      }
    };
  }

  function showTryAgain(message) {
    voiceText.textContent = message || "Try again";
    tryAgainBtn.style.display = "inline-block";
    stopBtn.style.display = "none";
  }

  // Start search bar
  searchIcon.addEventListener("click", function (e) {
    e.stopPropagation();
    searchSection.classList.add("active");
    searchIcon.style.display = "none";
    setTimeout(() => searchInput.focus(), 300);
  });

  document.addEventListener("click", function (e) {
    if (!searchSection.contains(e.target)) {
      searchSection.classList.remove("active");
      searchIcon.style.display = "inline-block";
    }
  });

  searchSection.addEventListener("click", function (e) {
    e.stopPropagation();
  });

  searchInput.addEventListener("input", () => {
    clearBtn.style.display = searchInput.value ? "inline-block" : "none";
  });

  clearBtn.addEventListener("click", () => {
    searchInput.value = "";
    clearBtn.style.display = "none";
    searchInput.focus();
  });

  // Start voice on mic click
  voiceBtn.addEventListener("click", () => {
    startVoiceRecognition();
  });

  stopBtn.addEventListener("click", () => {
    if (recognition) recognition.stop();
    showTryAgain("Stopped. No speech detected.");
  });

  tryAgainBtn.addEventListener("click", () => {
    stopBtn.style.display = "inline-block";
    startVoiceRecognition();
  });

  voiceClose.addEventListener("click", () => {
    if (recognition) recognition.stop();
    voicePopup.style.display = "none";
  });
});



// desktop header

      // Handle underline animation
  const menus = document.querySelectorAll('.desktop-menu');
  menus.forEach(menu => {
    menu.addEventListener('click', (e) => {
      e.stopPropagation();
      menus.forEach(m => m.classList.remove('active'));
      menu.classList.add('active');
    });
  });
  
  // Toggle submenu
  const mainMenu = document.querySelector('.main-menu2');
  const submenu = document.querySelector('.desktop-submenu');
  
  mainMenu.addEventListener('click', (e) => {
    e.stopPropagation();
    mainMenu.classList.toggle('show-sub');
  });
  
  // Prevent closing when clicking inside submenu
  submenu.addEventListener('click', (e) => {
    e.stopPropagation();
  });
  
  // Close submenu when clicking outside
  document.addEventListener('click', () => {
    mainMenu.classList.remove('show-sub');
  });
  document.addEventListener("DOMContentLoaded", function() {
  const searchInput = document.getElementById("searchInput");
  const clearBtn = document.querySelector(".clear-input");
  
  // Show/hide clear button
  searchInput.addEventListener("input", () => {
    clearBtn.style.display = searchInput.value ? "inline-block" : "none";
  });
  
  // Clear input on click
  clearBtn.addEventListener("click", () => {
    searchInput.value = "";
    clearBtn.style.display = "none";
    searchInput.focus();
  });
});
