document.addEventListener('DOMContentLoaded', () => {
  const params = new URLSearchParams(window.location.search);
  const query = params.get("q")?.trim();
  const resultsDiv = document.getElementById("searchResults");
  const loadingIndicator = document.getElementById("loadingIndicator");
  const resultsHeader = document.getElementById("resultsHeader");
  const startTime = performance.now();

  if (!query) {
    resultsHeader.style.display = 'none';
    loadingIndicator.style.display = 'none';
    resultsDiv.innerHTML = `
      <div class='no-results'>
        <h2>No Results Found</h2>
        <p>You didn’t type anything. Please enter a keyword to search.</p>
        <form method='get'>
          <input class='input-1' name='q' placeholder='Search for mantras, stotras, bhajans...' type='text'/>
          <button type='submit'>Search</button>
        </form>
      </div>
    `;
    return;
  }

  loadingIndicator.style.display = 'block';
  document.getElementById("searchQuery").textContent = query;

  // Filter by title1 but show title2
  const filteredCards = cards.filter(card =>
    card.title1.toLowerCase().includes(query.toLowerCase())
  );

  const total = filteredCards.length;

  // Random loading delay 1700–4300ms
  const minLoading = Math.floor(Math.random() * (2700 - 800 + 1)) + 800;
  const elapsedTime = performance.now() - startTime;
  const remainingTime = minLoading - elapsedTime;

  const showResults = () => {
    const timeTaken = ((performance.now() - startTime) / 1000).toFixed(2);
    document.getElementById("totalResults").textContent = `${total} Post${total !== 1 ? 's' : ''}`;
    document.getElementById("searchTime").textContent = `${timeTaken} sec`;

    if (total === 0) {
      resultsHeader.style.display = 'none';
      resultsDiv.innerHTML = `
        <div class='no-results'>
          <h2>No Results Found</h2>
          <p>Sorry, we couldn't find any posts matching your search.</p>
          <form method='get'>
            <input class='input-1' name='q' placeholder='Search for mantras, stotras, bhajans...' type='text'/>
            <button type='submit'>Search</button>
          </form>
        </div>
      `;
    } else {
      resultsHeader.style.display = 'flex';
      resultsDiv.innerHTML = filteredCards.map(card => `
        <div class="card">
          <a href="${card.url}" class="card-link">
            <div class="card-icon">
              <img src="${card.thumbnail}" alt="Image">
            </div>
            <h3>${card.title2}</h3>
          </a>
        </div>
      `).join('');
    }

    loadingIndicator.style.display = 'none';
  };

  if (remainingTime > 0) {
    setTimeout(showResults, remainingTime);
  } else {
    showResults();
  }
});
