// Replace the existing favorite JavaScript with this
document.addEventListener('DOMContentLoaded', function() {
  // Initialize favorites from localStorage
  const favorites = JSON.parse(localStorage.getItem('favorites')) || [];
  
  // Setup favorite icons
  document.querySelectorAll('.favorite-icon').forEach(icon => {
    const url = icon.getAttribute('data-url');
    const card = icon.closest('.card');
    const imgSrc = card.querySelector('.card-icon img').src;
    const title = card.querySelector('h2').textContent;
    
    // Check if this card is already favorited
    const isFavorite = favorites.some(fav => fav.url === url);
    
    // Update icon state
    if (isFavorite) {
      icon.classList.add('favorite');
      icon.innerHTML = '<i class="fas fa-heart"></i>';
    }
    
    // Add click handler
    icon.addEventListener('click', function(e) {
      e.preventDefault();
      e.stopPropagation();
      
      const index = favorites.findIndex(fav => fav.url === url);
      
      if (index === -1) {
        // Add to favorites
        favorites.push({
          url: url,
          title: title,
          image: imgSrc
        });
        this.classList.add('favorite');
        this.innerHTML = '<i class="fas fa-heart"></i>';
      } else {
        // Remove from favorites
        favorites.splice(index, 1);
        this.classList.remove('favorite');
        this.innerHTML = '<i class="far fa-heart"></i>';
      }
      
      // Save to localStorage
      localStorage.setItem('favorites', JSON.stringify(favorites));
    });
  });
});