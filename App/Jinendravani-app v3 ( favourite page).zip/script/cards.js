// Define global variable (no export)
var cards = [
  {
    title1: "Shri Aadinath Chalisa",
    title2: "श्री आदिनाथ चालीसा",
    url: "chalisa/Aadinath-chalisa.html",
    thumbnail: "chalisa-icon/Aadinath.png"
  },
  {
    title1: "Shri Ajitnath Chalisa",
    title2: "श्री अजितनाथ चालीसा",
    url: "chalisa/Ajitnath-chalisa.html",
    thumbnail: "chalisa-icon/Ajitnath.png"
  },
  {
    title1: "Shri Sambhavnath Chalisa",
    title2: "श्री सम्भवनाथ चालीसा",
    url: "chalisa/Sambhavnath-chalisa.html",
    thumbnail: "chalisa-icon/Sambhavnath.png"
  },
  {
    title1: "Shri Abhinandanath Chalisa",
    title2: "श्री अभिनंदननाथ चालीसा",
    url: "chalisa/Abhinandan-nath-chalisa.html",
    thumbnail: "chalisa-icon/Abhinandanath.png"
  },
  {
    title1: "Shri Sumatinath Chalisa",
    title2: "श्री सुमतिनाथ चालीसा",
    url: "chalisa/Sumatinath-chalisa.html",
    thumbnail: "chalisa-icon/Sumatinath.png"
  },
  {
    title1: "Shri Padmaprabhu Chalisa",
    title2: "श्री पद्मप्रभु चालीसा",
    url: "chalisa/Padamprabhu-chalisa.html",
    thumbnail: "chalisa-icon/Padmaprabhu.png"
  },
  {
    title1: "Shri Suparshvanath Chalisa",
    title2: "श्री सुपार्श्वनाथ चालीसा",
    url: "chalisa/Suparshvanath-chalisa.html",
    thumbnail: "chalisa-icon/Suparshvanatha.png"
  },
  {
    title1: "Shri Chandraprabhu Chalisa",
    title2: "श्री चंद्रप्रभु चालीसा",
    url: "chalisa/Chandraprabhu-chalisa.html",
    thumbnail: "chalisa-icon/Chandraprabhu.png"
  },
  {
    title1: "Shri Pushpadant Chalisa",
    title2: "श्री पुष्पदंत चालीसा",
    url: "chalisa/Pushpdant-chalisa.html",
    thumbnail: "chalisa-icon/Pushpadant.png"
  },
  {
    title1: "Shri Shitalanath Chalisa",
    title2: "श्री शीतलनाथ चालीसा",
    url: "chalisa/Sheetalnath-chalisa.html",
    thumbnail: "chalisa-icon/Shitalanath.png"
  },
  {
    title1: "Shri Shreyansnath Chalisa",
    title2: "श्री श्रेयांसनाथ चालीसा",
    url: "chalisa/Shreyansnath-chalisa.html",
    thumbnail: "chalisa-icon/Shreyansanatha.png"
  },
  {
    title1: "Shri Vasupujya Chalisa",
    title2: "श्री वासुपूज्य चालीसा",
    url: "chalisa/Vasupujya-chalisa.html",
    thumbnail: "chalisa-icon/vasupujya.png"
  },
  {
    title1: "Shri Vimalnath Chalisa",
    title2: "श्री विमलनाथ चालीसा",
    url: "chalisa/Vimalnath-chalisa.html",
    thumbnail: "chalisa-icon/vimalnath.png"
  },
  {
    title1: "Shri Anantanath Chalisa",
    title2: "श्री अनंतनाथ चालीसा",
    url: "chalisa/Anantnath-chalisa.html",
    thumbnail: "chalisa-icon/Anantanath.png"
  },
  {
    title1: "Shri Dharamnath Chalisa",
    title2: "श्री धर्मनाथ चालीसा",
    url: "chalisa/Dharamnath-chalisa.html",
    thumbnail: "chalisa-icon/Dharamnath.png"
  },
  {
    title1: "Shri Shantinath Chalisa",
    title2: "श्री शांतिनाथ चालीसा",
    url: "chalisa/Shantinath-chalisa.html",
    thumbnail: "chalisa-icon/Shantinath.png"
  },
  {
    title1: "Shri Kunthunath Chalisa",
    title2: "श्री कुंथुनाथ चालीसा",
    url: "chalisa/Kunthunath-chalisa.html",
    thumbnail: "chalisa-icon/Kunthunath.png"
  },
  {
    title1: "Shri Aranath Chalisa",
    title2: "श्री अरहनाथ चालीसा",
    url: "chalisa/Arahnath-chalisa.html",
    thumbnail: "chalisa-icon/Arahnath.png"
  },
  {
    title1: "Shri Mallinath Chalisa",
    title2: "श्री मल्लिनाथ चालीसा",
    url: "chalisa/Mallinath-chalisa.html",
    thumbnail: "chalisa-icon/Mallinath.png"
  },
  {
    title1: "Shri Munisuvrat Chalisa",
    title2: "श्री मुनिसुव्रतनाथ चालीसा",
    url: "chalisa/Munisuvrathnath-chalisa.html",
    thumbnail: "chalisa-icon/Munisuvrat.png"
  },
  {
    title1: "Shri Naminath Chalisa",
    title2: "श्री नमिनाथ चालीसा",
    url: "chalisa/Naminath-chalisa.html",
    thumbnail: "chalisa-icon/Naminath.png"
  },
  {
    title1: "Shri Neminath Chalisa",
    title2: "श्री नेमिनाथ चालीसा",
    url: "chalisa/Neminath-chalisa.html",
    thumbnail: "chalisa-icon/Neminath.png"
  },
  {
    title1: "Shri Parshvanath Chalisa",
    title2: "श्री पार्श्वनाथ चालीसा",
    url: "chalisa/Parshvnath-chalisa.html",
    thumbnail: "chalisa-icon/Parshvanath.png"
  },
  {
    title1: "Shri Mahaveer Chalisa",
    title2: "श्री महावीर चालीसा",
    url: "chalisa/Mahaveer-chalisa.html",
    thumbnail: "chalisa-icon/Mahaveer.png"
  }
];
