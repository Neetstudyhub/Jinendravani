function fuzzyMatch(query, text) {
    query = query.toLowerCase();
    text = text.toLowerCase();
    let i = 0,
        j = 0;
    while (i < query.length && j < text.length) {
        if (query[i] === text[j]) i++;
        j++;
    }
    return i === query.length;
}

const input = document.getElementById("searchInput");
const suggestions = document.getElementById("suggestions");
const overlay = document.getElementById("overlay");

// Prefix for all local assets
const prefix = "file:///android_asset/";

input.addEventListener("input", () => {
    let query = input.value.toLowerCase().trim();
    suggestions.innerHTML = "";
    
    if (query.length === 0) {
        suggestions.style.display = "none";
        overlay.style.display = "none";
        document.body.style.overflow = "auto"; // enable scroll again
        return;
    }
    
    let results = cards.filter(item =>
        item.title1.toLowerCase().includes(query) ||
        item.title2.toLowerCase().includes(query) ||
        fuzzyMatch(query, item.title1) ||
        fuzzyMatch(query, item.title2)
    );
    
    suggestions.style.display = "grid";
    overlay.style.display = "block";
    document.body.style.overflow = "hidden"; // freeze background
    
    if (results.length === 0) {
        suggestions.innerHTML = `
      <div class="suggestion-card">
        <img src="${prefix}icons/notfound.png" alt="Not found">
        <div class="suggestion-text">
          <span class="suggestion-title1">No results found</span>
          <span class="suggestion-title2">Try another keyword</span>
        </div>
      </div>`;
        return;
    }
    
    results.forEach(item => {
        let card = document.createElement("div");
        card.className = "suggestion-card";
        
        let img = document.createElement("img");
        img.src = prefix + item.thumbnail;
        
        let textDiv = document.createElement("div");
        textDiv.className = "suggestion-text";
        
        let title1 = document.createElement("span");
        title1.className = "suggestion-title1";
        title1.textContent = item.title1;
        
        let title2 = document.createElement("span");
        title2.className = "suggestion-title2";
        title2.textContent = item.title2;
        
        textDiv.appendChild(title1);
        textDiv.appendChild(title2);
        card.appendChild(img);
        card.appendChild(textDiv);
        
        card.addEventListener("click", () => {
            window.location.href = prefix + item.url;
        });
        
        suggestions.appendChild(card);
    });
});

// Clear input
document.querySelector(".clear-input").addEventListener("click", () => {
    input.value = "";
    suggestions.innerHTML = "";
    suggestions.style.display = "none";
    overlay.style.display = "none";
    document.body.style.overflow = "auto"; // enable scroll
});

// Close overlay on click
overlay.addEventListener("click", () => {
    input.value = "";
    suggestions.innerHTML = "";
    suggestions.style.display = "none";
    overlay.style.display = "none";
    document.body.style.overflow = "auto";
});